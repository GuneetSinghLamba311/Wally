//
//  WelcomeVC.swift
//  LandMark
//
//  Created by Admin on 2019-02-04.
//  Copyright © 2019 Guneet SIngh Lamba. All rights reserved.
//

import UIKit

class WelcomeVC: UIViewController {
    
    @IBOutlet weak var welcome: UILabel!
   let value = true
    override func viewDidLoad() {
        super.viewDidLoad()
    playBackgroundVideo()
    }
    
    
    func playBackgroundVideo() {
    performSegue(withIdentifier: "maintoLoad", sender: nil)
    }

}
