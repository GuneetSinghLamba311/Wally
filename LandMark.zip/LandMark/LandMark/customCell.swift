//
//  customCell.swift
//  LandMark
//
//  Created by Admin on 2019-02-02.
//  Copyright © 2019 Guneet SIngh Lamba. All rights reserved.
//

import UIKit

class customCell: UICollectionViewCell {
@IBOutlet weak var unsplashImage: UIImageView!
}
