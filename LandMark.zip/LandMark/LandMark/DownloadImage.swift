//
//  DownloadImage.swift
//  LandMark
//
//  Created by Admin on 2019-02-04.
//  Copyright © 2019 Guneet SIngh Lamba. All rights reserved.
//

import UIKit

class DownloadImage: UIViewController {

    var imageURL:URL?
    
    @IBOutlet weak var downloadImage: UIImageView!
    @IBAction func downoadImageButton(_ sender: Any) {
        UIImageWriteToSavedPhotosAlbum(downloadImage.image!, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
    }
    //MARK: - Add image to Library
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let alertAction = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            alertAction.addAction(UIAlertAction(title: "OK", style: .default))
            present(alertAction, animated: true)
        } else {
            let alertAction = UIAlertController(title: "Saved!", message: "Your  image has been saved to photos.", preferredStyle: .alert)
            alertAction.addAction(UIAlertAction(title: "OK", style: .default))
            present(alertAction, animated: true)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            downloadImage.image = try UIImage(data: Data(contentsOf: imageURL!))
            
        }catch {
            print(error)
        }
        
    }

}
